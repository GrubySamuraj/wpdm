class MyModel1:
    def __init__(self):
        pass

class MyModel2:
    def __init__(self):
        pass

