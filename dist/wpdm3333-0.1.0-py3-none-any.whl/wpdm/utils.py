def foo(x,y):
    """

    :param x:
    :param y:
    :return:
    """
    return x-y

def printuj(f):
    print(f)
